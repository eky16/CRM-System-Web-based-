<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
			<a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/dashboard') ?>"	>
				<div class="sidebar-brand-icon rotate-n-11">
					<img style="width: 70px;height: 70px" src="<?php echo base_url(); ?>img/logo.png"  alt="" class="img-circle"/>
				</div>
				<div class="sidebar-brand-text mx-3">Cassa<sup>Design</sup></div>
			</a>
			<hr class="sidebar-divider my-0">

			<li class="nav-item <?= $aktif == 'dashboard' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('user/dashboard') ?>">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span>Dashboard</span></a>
			</li>
		<!--	<hr class="sidebar-divider">	
			<div class="sidebar-heading">
				Master
			</div>
			 Master Data
           	<li class="nav-item <?= $aktif == 'leads' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Master Leads Project</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Data Leads Project:</h6>
                        <a class="collapse-item" href="<?= base_url('leads') ?>">Leads Project</a>
                    </div>
                </div>
            </li> -->
<!--
			<li class="nav-item <?= $aktif == 'barang' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('barang') ?>">
					<i class="fas fa-fw fa-box"></i>
					<span>Master Data Leads</span></a>
			</li>

			<li class="nav-item <?= $aktif == 'customer' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('customer') ?>">
					<i class="fas fa-fw fa-user"></i>
					<span>Master Customer</span></a>
			</li>

			<li class="nav-item <?= $aktif == 'supplier' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('supplier') ?>">
					<i class="fas fa-fw fa-user"></i>
					<span>Master Supplier</span></a>
			</li>

			<li class="nav-item <?= $aktif == 'petugas' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('petugas') ?>">
					<i class="fas fa-fw fa-users"></i>
					<span>Master Petugas</span></a>
			</li>	
                 -->
			<!-- Divider
			<hr class="sidebar-divider">
	
			<div class="sidebar-heading">
				MINUTES OF MEETING
			</div>

				<li class="nav-item <?= $aktif == 'mom' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#mom"
                    aria-expanded="false" aria-controls="mom">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Minutes Of Meeting</span>
                </a>
                <div id="mom" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Data M O M:</h6>
                        <a class="collapse-item" href="<?= base_url('user/mom/lihat_semua') ?>">M O M</a>
                        <a class="collapse-item" href="<?= base_url('user/mom/lihat_semua_goal') ?>">M O M GOAL</a>
                        <a class="collapse-item" href="<?= base_url('user/mom/lihat_nogoal') ?>">M O M TIDAK</a>
                    </div>
                </div>
            </li> -->

<!-- MENU KARYAWAN -->
			<hr class="sidebar-divider">
	
			<div class="sidebar-heading">
			<strong>HRMS</strong>	
			</div>

				<li class="nav-item <?= $aktif == 'Employee' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Employee"
                    aria-expanded="false" aria-controls="Employee">
                    <i class="fas fa-fw fa-users"></i>
                    <span>PROFIL SAYA</span>
                </a>
                <div id="Employee" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded"> 
                    <?php  $id = $this->session->login['kode']; ?>
                        <a class="collapse-item" href="<?= base_url('user/karyawan/detail/') ?><?= $id ?>">LIHAT</a>
                    </div>
                </div>
            </li><!-- END MENU KARYAWAN -->

				<li class="nav-item <?= $aktif == 'dept' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dept"
                    aria-expanded="false" aria-controls="dept">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>IZIN</span>
                </a>
                <div id="dept" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                      
                        <a class="collapse-item " href="<?= base_url('user/dept/lihat_semua') ?>">LIST</a>
                    </div>
                </div>
            </li><!-- END MENU DEPARTMENT -->
				<li class="nav-item <?= $aktif == 'dept' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#kehadiran"
                    aria-expanded="false" aria-controls="kehadiran">
                    <i class="fas fa-fw fa-sticky-note"></i>
                    <span>KEHADIRAN</span>
                </a>
                <div id="kehadiran" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                      
                        <a class="collapse-item " href="<?= base_url('user/absensi') ?>">LIST</a>
                    </div>
                </div>
            </li><!-- END MENU DEPARTMENT -->
<!--
			<li class="nav-item <?= $aktif == 'penerimaan' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('penerimaan') ?>">
					<i class="fas fa-fw fa-file-invoice"></i>
					<span>Transaksi Penerimaan</span></a>
			</li>

			<li class="nav-item <?= $aktif == 'pengeluaran' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('pengeluaran') ?>">
					<i class="fas fa-fw fa-file-invoice"></i>
					<span>Transaksi Pengeluaran</span></a>
			</li>

			<hr class="sidebar-divider">
			<?php if ($this->session->login['role'] == 'admin'): ?>
				
				<div class="sidebar-heading">
					Pengaturan
				</div>

				<li class="nav-item <?= $aktif == 'pengguna' ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url('pengguna') ?>">
						<i class="fas fa-fw fa-users"></i>
						<span>Manajemen Pengguna</span></a>
				</li>

				<li class="nav-item <?= $aktif == 'toko' ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url('toko') ?>">
						<i class="fas fa-fw fa-building"></i>
						<span>Profil Perusahaan</span></a>
				</li>
				<!-- Divider -->
			<?php endif; ?>
			<hr class="sidebar-divider d-none d-md-block">

			<!-- Sidebar Toggler (Sidebar) -->
			<div class="text-center d-none d-md-inline">
				<button class="rounded-circle border-0" id="sidebarToggle"></button>
			</div>
		</ul>