<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('partials/head.php') ?>
	<style type="text/css">
		#hidden_div { 
    display: none;
}
	</style>
</head>

<body id="page-top">
	<div id="wrapper">
		<!-- load sidebar -->
		<?php $this->load->view('partials/sidebar.php') ?>

		<div id="content-wrapper" class="d-flex flex-column">
			<div id="content" data-url="<?= base_url('leads') ?>">
				<!-- load Topbar -->
				<?php $this->load->view('partials/topbar.php') ?>

				<div class="container-fluid">
				<div class="clearfix">
					<div class="float-left">
						<h1 class="h3 m-0 text-gray-800"><?= $title ?></h1>
					</div>
					<div class="float-right">

					<button  class="btn btn-secondary btn-sm" onclick="history.back()"><i class="fa fa-reply"></i> &nbsp;&nbsp;Kembali</button>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<div class="card shadow">
							<div class="card-header"><strong>Isi Form Dibawah Ini!</strong></div>
							<div class="card-body">
								<form action="<?= base_url('leads/proses_ubah/' . $leads->id_lsp) ?>" id="form-tambah" method="POST">
								<div class="form-row">
										<div class="form-group col-md-3">
											<label for="kode_barang"><strong>Kode Leads Project</strong></label>
											<input type="text" name="id_lsp" placeholder="Masukkan Kode " autocomplete="off"  class="form-control" required value="<?= $leads->id_lsp ?>" maxlength="8" readonly>
										</div>
											<div class="form-group col-md-3">
											<label ><strong>User</strong></label>
											<input type="text" name="createdby" placeholder="Masukkan Kode Barang" autocomplete="off"  class="form-control" required value="<?= $leads->createdby ?>" maxlength="8" readonly>
										</div>
										<div class="form-group col-6">
										<label>Tanggal</label>
										<input type="text" readonly name="createdtime" value="<?= $leads->createdtime ?>"  class="form-control">
											</div>
							       <input type="hidden" name="updateby" value="<?php echo  $this->session->login['nama'] ?>">
                             		<input type="hidden" name="updatetime" value="<?php date_default_timezone_set('Asia/Jakarta');
                                echo date('Y-m-d  H:i:s');
                                ?>">
									</div>
									<div class="form-row">

										<div class="form-group col-md-3">
											<label for="nama_barang"><strong>Nama PIC</strong></label>
											<input type="text" name="nama_pic" placeholder="Masukkan Nama PIC" autocomplete="off" value="<?= $leads->nama_pic ?>" maxlength="50"  class="form-control" required>
										</div>
										<div class="form-group col-3">
											<label>No Telp</label>

											<input  oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
											    type = "number"
											    maxlength = "15" name="no_telp" placeholder="Masukkan No Tlp"  value="<?= $leads->no_telp ?>"  class="form-control">
										</div>
										<div class="form-group col-6">
											<label>Email</label>
											<input type="email" name="email" placeholder="Masukkan Email" autocomplete="off" value="<?= $leads->email ?>"  class="form-control">
										</div>
									</div>

									<div class="form-row">

										<div class="form-group col-md-6">
											<label for="nama_barang"><strong>Nama Project</strong></label>
											<input type="text" name="nama_project" placeholder="Masukkan Nama Project" autocomplete="off" maxlength="50"  class="form-control" value="<?= $leads->nama_project ?>" required>
										</div>
										<div class="form-group col-md-6">
											<label for="nama_barang"><strong>Nama Perusahaan</strong></label>
											<input type="text" name="nama_kantor" placeholder="Masukkan Nama Perusahaan" autocomplete="off" maxlength="50" value="<?= $leads->nama_kantor ?>"  class="form-control" >
										</div>
										<div class="form-group col-6">
											<label>Alamat Project</label>
										<textarea  name="alamat_project" class="form-control" ><?= $leads->alamat_project ?></textarea>
										</div>
										<div class="form-group col-6">
											<label>Alamat Perusahaan</label>
											<textarea  name="alamat_kantor" class="form-control" ><?= $leads->alamat_kantor ?></textarea>
									</div>
									<div class="form-group col-6" >
											<label>Telp Perusahaan</label>
											<input  oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
											    type = "number"
											    maxlength = "15" name="tlp_kantor" placeholder="Masukkan No Tlp Kantor"  value="<?= $leads->tlp_kantor ?>"  class="form-control">
										</div>
										<div class="form-group col-6" >
											<label>Status Project</label>
							<select id="select-state" placeholder="Status Project" name="status_project" class="form-control" onchange="showDiv('hidden_div', this)" required>           
			                 <option value="" >PILIH .....</option>
                            <?php foreach ($all_status_project as $status) : ?>
                                <option value="<?php echo $status->keterangan ?>" <?php
                                if (!empty($leads->status_project)) {
                                    echo $status->keterangan == $leads->status_project ? 'selected' : '';
                                }
                                ?>><?php echo $status->keterangan ?></option>
                                    <?php endforeach; ?>

			                       </select> 

			             

										</div>
                                	<div class="form-group col-12" id="hidden_div">
	                                    <label>Keterangan</label>
	                                        <textarea  name="keterangan_loose" class="form-control" ><?php
                                if (!empty($emp->keterangan_loose)) {
                                    echo $emp->keterangan_loose ;
                                }
                                ?></textarea>
	                                        </div>
									</div>
									
					<input type="text" name="ket" placeholder="Masukkan Kode Barang" autocomplete="off"  class="form-control" required value="Ubah Leads Project" maxlength="8" hidden>
                    <input type="hidden" name="user" value="<?php echo  $this->session->login['nama'] ?>">
                    <input type="hidden" name="waktu" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('Y-m-d  H:i:s'); ?>"> 						
									<div class="form-row">
						
									<hr>
									<div class="form-group  ">
										<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i>&nbsp;&nbsp;Simpan</button>
										<button type="reset" class="btn btn-danger"><i class="fa fa-times"></i>&nbsp;&nbsp;Batal</button>
									</div>
								</form>
							</div>				
						</div>
					</div>
				</div>

				</div>
			</div>
<script type="text/javascript">
    function showDiv(divId, element)
{
    document.getElementById(divId).style.display = element.value == "LOOSE" ? 'block' : 'none' ;
   
}
</script>
			<!-- load footer -->
			<?php $this->load->view('partials/footer.php') ?>
		</div>
	</div>
	<?php $this->load->view('partials/js.php') ?>
</body>
</html>