<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('partials/head.php') ?>
</head>

<body id="page-top">
	<div id="wrapper">
		<!-- load sidebar -->
		<?php $this->load->view('partials/sidebar.php') ?>

		<div id="content-wrapper" class="d-flex flex-column">
			<div id="content" data-url="<?= base_url('leads') ?>">
				<!-- load Topbar -->
				<?php $this->load->view('partials/topbar.php') ?>

				<div class="container-fluid">
				<div class="clearfix">
					<div class="float-left">
						<h1 class="h3 m-0 text-gray-800"><?= $title ?></h1>
					</div>
					<div class="float-right">
						<?php if ($this->session->login['role'] == 'admin'): ?>
					<a href="<?= base_url('mom/tambah') ?>" class="btn btn-info btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Buat M O M </a>
					<a href="<?= base_url('leads/tambah') ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data Leads Project</a>
					<a href="<?= base_url('leads/ubah/' . $all_leads->id_lsp) ?>" class="btn btn-success btn-sm"><i class="fa fa-pen"></i>&nbsp;&nbsp;Ubah</a>
						<?php endif ?>

					<button  class="btn btn-secondary btn-sm" onclick="history.back()"><i class="fa fa-reply"></i> &nbsp;&nbsp;Kembali</button>					</div>
				</div>
				<hr>
				<?php if ($this->session->flashdata('success')) : ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
						<?= $this->session->flashdata('success') ?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php elseif($this->session->flashdata('error')) : ?>
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<?= $this->session->flashdata('error') ?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php endif ?>
     <div class="row">
		 			<div class="col-lg-12 mb-4">
                            <!-- Project Card Example -->
                            <div class="card shadow ">
                                <div class="card-header py-4">
                                    <h6 class="m-0 font-weight-bold text-primary"><?= $all_leads->nama_project ?></h6>
                                </div>
                    
                            </div>
				</div>
</div>
           <div class="row">

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">INFORMASI PROJECT</h6>
                                </div>
                                <div class="card-body">
                               	<div class="form-row">
                                   
                            		<div class="form-group col-md-4">
											<label for="kode_barang"><strong>Kode Leads Project</strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->id_lsp ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Nama PIC </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->nama_pic ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>No Telp </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->no_telp ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Email </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->email ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Status Project </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?php
                                    if ($all_leads->status_project == 'TENDER') {
                                        echo '<a class="btn btn-success btn-sm" style="color:white">TENDER</a>';
                                    } elseif ($all_leads->status_project == 'ON GOING') {

                                        echo '<a class="btn btn-primary btn-sm" style="color:white">ON GOING</a>';
                                       
                                    }
                                   elseif ($all_leads->status_project == 'PENDING') {

                             echo '<a class="btn btn-outline-success btn-sm" style="color:black"> PENDING</a>';

                                       
                                    } elseif ($all_leads->status_project == 'FINISH'){
                                       
                                        echo '<a class="btn btn-warning btn-sm" style="color:white">FINISH</a>';
                                    }
                                    else {
                                       
                                        echo '<a class="btn btn-danger btn-sm" style="color:white">LOOSE</a>';
                                    }
                                    ?>
										</div>
									<div class="form-group col-md-4">

									<label for="kode_barang"><strong>Keterangan </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->keterangan_loose ?>
										</div>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div class="col-lg-6 mb-4">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">INFORMASI PROJECT</h6>
                                </div>
                                <div class="card-body">
                                                                   	<div class="form-row">
                                   
                            		<div class="form-group col-md-4">
											<label for="kode_barang"><strong>Nama Project</strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->nama_project ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Alamat Project </strong>
											</label>
										</div>
										<div class="form-group col-md-8">:
											<?= $all_leads->alamat_project ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Nama Perusahaan </strong>
											</label>
										</div>
										<div class="form-group col-md-7">:
											<?= $all_leads->nama_kantor ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>No Telp </strong>
											</label>
										</div>
										<div class="form-group col-md-5">:
											<?= $all_leads->tlp_kantor ?>
										</div>
								    <div class="form-group col-md-4">
											<label for="kode_barang"><strong>Alamat Perusahaan</strong>
											</label>
										</div>
										<div class="form-group col-md-8">:
											<?= $all_leads->alamat_kantor ?>
										</div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
			</div>
			<!-- load footer -->
			<?php $this->load->view('partials/footer.php') ?>
		</div>
	</div>
	<?php $this->load->view('partials/js.php') ?>
	<script src="<?= base_url('sb-admin/js/demo/datatables-demo.js') ?>"></script>
	<script src="<?= base_url('sb-admin') ?>/vendor/datatables/jquery.dataTables.min.js"></script>
	<script src="<?= base_url('sb-admin') ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
</body>
</html>