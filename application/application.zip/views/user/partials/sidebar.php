 <?php error_reporting(0); ?>
 <style>
  .dropdown-toggle::after {
    content: "";
    display: inline-block;
    width: 0;
    height: 0;
    border-top: 20px solid transparent; /* Adjust this value to change the size of the arrow */
    border-bottom: 20px solid transparent; /* Adjust this value to change the size of the arrow */
    border-left: 20px solid #000; /* Adjust this value to change the color of the arrow */
    margin-left: 20px; /* Adjust this value to change the distance between the text and the arrow */
  }
</style>
 <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
			<a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/dashboard') ?>"	>
				<div class="sidebar-brand-icon rotate-n-11">
					<img style="width: 70px;height: 70px" src="<?php echo base_url(); ?>img/logo01.png"  alt="" class="img-circle"/>
				</div>
				<div class="sidebar-brand-text mx-3">Alba<sup>Unggul</sup></div>
			</a><br>
			<hr class="sidebar-divider my-0">

			<li class="nav-item <?= $aktif == 'dashboard' ? 'active' : '' ?>"> 
				<a class="nav-link" href="<?= base_url('user/dashboard') ?>">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span>Dashboard</span></a>
			</li>


            <hr class="sidebar-divider">    
            <div class="sidebar-heading">
                Alba Unggul Metal
            </div>
            <!--
            <li class="nav-item <?= $aktif == 'leads' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Leads Project</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Data Project:</h6>
                    
            
                         <a class="collapse-item" href="<?= base_url('user/leads') ?>">Pending / Tender</a>
                         <a class="collapse-item" href="<?= base_url('user/leads/ongoing') ?>">On Going</a>
                         <a class="collapse-item" href="<?= base_url('user/leads/retensi') ?>">Retensi</a>
                         <a class="collapse-item" href="<?= base_url('user/leads/finish') ?>">Finish</a>
                         <a class="collapse-item" href="<?= base_url('user/leads/Lose') ?>">Lose</a>
              

                    </div>
                </div>
            </li>
-->



<!-- END MENU REMBES --><!-- END Payment REMBES -->
<?php if ($this->session->login['department'] == 'PPIC' OR $this->session->login['department'] == 'IT' OR $this->session->login['department'] == 'Marketing'):?>
<li class="nav-item <?= $aktif == 'customer' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Customer</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Data Customer :</h6>
                    <a class="collapse-item" href="<?= base_url('user/customer/tambah') ?>">Tambah</a>
                    <a class="collapse-item" href="<?= base_url('user/customer') ?>">Lihat</a>
                     <a class="collapse-item" href="<?= base_url('user/customer/nonaktif') ?>">Non-Aktif</a>
                </div>
                </div>
            </li>
            <?php endif; ?>


<!-- Bagian HTML untuk MSP (Actual) -->
<?php if ($this->session->login['department'] == 'PPIC' OR $this->session->login['department'] == 'IT' OR $this->session->login['department'] == 'Produksi'):?>

<li class="nav-item <?= $aktif == 'msa' ? 'active' : '' ?>">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" id="droptog_approved1" data-target="#msa"
        aria-expanded="false" aria-controls="msa">
        <i class="fas fa-fw fa fa-list-alt"></i>
        <span>MSP (Actual)</span>
    </a>
    <div id="msa" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_actual_line1') ?>">MSP(Actual) Line 1</a>                
            <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_actual_line2') ?>">MSP(Actual) Line 2</a>
            <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_actual_line3') ?>">MSP(Actual) Line 3 </a>
        </div>
    </div>
</li>
<?php endif; ?>

<?php if ($this->session->login['department'] == 'PPIC' OR $this->session->login['department'] == 'IT' OR $this->session->login['department'] == 'Produksi'):?>
 <li class="nav-item <?= $aktif == 'msp' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" id="droptog_approved1" data-target="#msp"
                    aria-expanded="false" aria-controls="msp">
                    <i class="fas fa-fw fa fa-list-alt"></i>
                    <span>MSP</span>
    
                </a>
                <div id="msp" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                     <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_line1') ?>">MSP Line 1</a>                
                    <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_line2') ?>">MSP Line 2</a>
                   <a class="collapse-item" href="<?= base_url('user/wo/master_schedule_produksi_line3') ?>">MSP Line 3 </a>
                    </div>
                </div>
            </li>
<?php endif; ?>

<?php if ($this->session->login['department'] == 'PPIC' OR $this->session->login['department'] == 'IT' OR $this->session->login['department'] == 'Produksi' OR $this->session->login['department'] == 'Engineering'):?>
<li class="nav-item <?= $aktif == 'master_wo' ? 'active' : '' ?>"> 
                <a class="nav-link" href="<?= base_url('user/wo/master_wo') ?>">
                    <i class="fas fa-fw fa-book"></i>
                    <span>Master Work Order</span></a>
            </li>
<?php endif; ?>

<li class="nav-item <?= $aktif == 'master_forecast' ? 'active' : '' ?>"> 
                <a class="nav-link" href="<?= base_url('user/wo/master_forecast') ?>">
                    <i class="fas fa-fw fa-book"></i>
                    <span>Master Forecast</span></a>
            </li>


         <li class="nav-item <?= $aktif == 'pembelian' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" id="droptog_approved1" data-target="#pembelian"
                    aria-expanded="false" aria-controls="pembelian">
                    <i class="fas fa-fw fa fa-list-alt"></i>
                    <span>Proses Order</span>
                </a>
                <div id="pembelian" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">

                    <?php
                    $cek_jabatan = trim($emp->divisi . ' ' . $emp->department);
                    //var_dump($emp->divisi);
                    //var_dump($emp->department);
                    if ($cek_jabatan == 'Staff PPIC' || $cek_jabatan == 'Staff Marketing') {
                        //echo 'Menampilkan "Tambah Sales Order"';
                        ?>
                <a class="collapse-item" href="<?= base_url('user/wo/tambah') ?>">Tambah Sales Order</a>
                        <?php
                    }
                    //var_dump('After Condition');?>



                    <a class="collapse-item" href="<?= base_url('user/wo/list_permintaan') ?>">List Sales Order </a>
                    
            <?php if ($this->session->login['department'] == 'PPIC' OR $this->session->login['department'] == 'IT' OR $this->session->login['department'] == 'Produksi'):?>
                    <div class="dropdown dropright">
                        <a  class="collapse-item dropdown-toggle"  data-toggle="dropdown" href="#">
                       Produksi Line 1 
                      </a>
                      <div class="dropdown-menu">
                          <a class="dropdown-item" href="<?= base_url('user/wo/produksi_line1') ?>">Work Order</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/cutting_line1') ?>">Cutting</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/punching_line1') ?>">Punching</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/bending_line1') ?>">Bending</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/welding_line1') ?>">Welding</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/ps_line1') ?>">PS</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/fa_line1') ?>">FA</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/packing_line1') ?>">Packing</a>
                         
                          <!--   <a class="dropdown-item" href="#">Link 3</a> -->
                      </div>
                  </div> 
                   <div class="dropdown dropright">
                        <a  class="collapse-item dropdown-toggle"  data-toggle="dropdown" href="#">
                       Produksi Line 2
                      </a>
                      <div class="dropdown-menu">
                          <a class="dropdown-item" href="<?= base_url('user/wo/produksi_line2') ?>">Work Order</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/cutting_line2') ?>">Cutting</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/punching_line2') ?>">Punching</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/bending_line2') ?>">Bending</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/welding_line2') ?>">Welding</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/ps_line2') ?>">PS</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/fa_line2') ?>">FA</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/packing_line2') ?>">Packing</a>

                          <!--   <a class="dropdown-item" href="#">Link 3</a> -->
                      </div>
                  </div> 
                   <div class="dropdown dropright">
                        <a  class="collapse-item dropdown-toggle"  data-toggle="dropdown" href="#">
                       Produksi Line 3
                      </a>
                      <div class="dropdown-menu">
                          <a class="dropdown-item" href="<?= base_url('user/wo/produksi_line3') ?>">Work Order</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/cutting_line3') ?>">Cutting</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/punching_line3') ?>">Punching</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/bending_line3') ?>">Bending</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/welding_line3') ?>">Welding</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/ps_line3') ?>">PS</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/fa_line3') ?>">FA</a>
                          <a class="dropdown-item" href="<?= base_url('user/wo/packing_line3') ?>">Packing</a>
                          <!--   <a class="dropdown-item" href="#">Link 3</a> -->
                      </div>
                  </div> 
                    <a class="dropdown-item" href="<?= base_url('user/wo/packing') ?>">Packing</a>
                    <a class="collapse-item" href="<?= base_url('user/wo/Forecast') ?>">Forecast</a>
                    <a class="dropdown-item" href="<?= base_url('user/wo/subcon') ?>">Subcon</a>
                    <a class="collapse-item" href="<?= base_url('user/wo/wh_fg') ?>">WH FG </a>
                    <a class="collapse-item" href="<?= base_url('user/wo/booking') ?>">Booking </a>
                    <a class="collapse-item" href="<?= base_url('user/wo/pengiriman') ?>">Siap Dikirim </a>
                    <a class="collapse-item" href="<?= base_url('user/wo/selesai') ?>">Selesai </a>
                    <a class="collapse-item" href="<?= base_url('user/wo/pesanan_dibatalkan') ?>">Dibatalkan </a> 
                   <?php endif; ?>
                  <!--  <a class="collapse-item" href="<?= base_url('user/wo/list_selesai') ?>">Riwayat Pesanan Pembelian </a> -->
                 <!--   <a class="collapse-item" href="<?= base_url('user/wo/list_history_permintaan') ?>">Riwayat Permintaan Barang</a>
                    <a class="collapse-item" href="<?= base_url('user/wo/list_pesanan_pembelian_reject') ?>">Reject</a> 
                    <a class="collapse-item" href="<?= base_url('user/wo/laporan_01') ?>">Laporan</a>
                  -->
                    </div>
                </div>
            </li>

<!--  Barang -->


         <li class="nav-item <?= $aktif == 'barang' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" id="droptog_approved1" data-target="#barang"
                    aria-expanded="false" aria-controls="barang">
                    <i class="fas fa-fw fa fa-list-alt"></i>
                    <span>Barang Stok</span>
    
                </a>
                <div id="barang" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                     <a class="collapse-item" href="<?= base_url('user/barang') ?>">Stock Finish Good</a>                
                    <a class="collapse-item" href="<?= base_url('user/penerimaan') ?>">Transaksi Penerimaan</a>
                   <a class="collapse-item" href="<?= base_url('user/barang/list_pengeluaran') ?>">Transaksi Pengeluaran </a>
                   <a class="collapse-item" href="<?= base_url('user/barang/item_selesai_forecast') ?>">Riwayat Forecast -> Stok </a>
                    <a class="collapse-item" href="<?= base_url('user/barang/list_riwayat_stok') ?>">Riwayat Stok </a>
                    <!-- <a class="collapse-item" href="<?= base_url('user/barang/list_riwayat_stok2') ?>">Riwayat Stok 2</a> -->
                    </div>
                </div>
            </li>
            

           
  <!--   MENU KARYAWAN -->
			<hr class="sidebar-divider">
	
			<div class="sidebar-heading">
			<strong>HRMS</strong>	
			</div>

				<li class="nav-item <?= $aktif == 'Employee' ? 'active' : '' ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Employee"
                    aria-expanded="false" aria-controls="Employee">
                    <i class="fas fa-fw fa-users"></i>
                    <span>PROFIL SAYA</span>
                </a>
                <div id="Employee" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded"> 
                    <?php  $id = $this->session->login['kode']; ?>
                        <a class="collapse-item" href="<?= base_url('user/karyawan/detail/') ?><?= $id ?>">LIHAT</a>
                    </div>
                </div>
            </li>
         


            			<li class="nav-item ">
				<a class="nav-link" href="<?= base_url('logout') ?>">
					<i class="fas fa-fw fa fa-sign-out" style="color:red"></i>
					<span>LOG OUT</span></a>
			</li>
<!--
			<li class="nav-item <?= $aktif == 'penerimaan' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('penerimaan') ?>">
					<i class="fas fa-fw fa-file-invoice"></i>
					<span>Transaksi Penerimaan</span></a>
			</li>

			<li class="nav-item <?= $aktif == 'pengeluaran' ? 'active' : '' ?>">
				<a class="nav-link" href="<?= base_url('pengeluaran') ?>">
					<i class="fas fa-fw fa-file-invoice"></i>
					<span>Transaksi Pengeluaran</span></a>
			</li>

			<hr class="sidebar-divider">
			<?php if ($this->session->login['role'] == 'admin'): ?>
				
				<div class="sidebar-heading">
					Pengaturan
				</div>

				<li class="nav-item <?= $aktif == 'pengguna' ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url('pengguna') ?>">
						<i class="fas fa-fw fa-users"></i>
						<span>Manajemen Pengguna</span></a>
				</li>

				<li class="nav-item <?= $aktif == 'toko' ? 'active' : '' ?>">
					<a class="nav-link" href="<?= base_url('toko') ?>">
						<i class="fas fa-fw fa-building"></i>
						<span>Profil Perusahaan</span></a>
				</li>
				 Divider -->
			<?php endif; ?>
			<hr class="sidebar-divider d-none d-md-block">

			<!-- Sidebar Toggler (Sidebar) -->
			<div class="text-center d-none d-md-inline">
				<button class="rounded-circle border-0" id="sidebarToggle"></button>
			</div>
		</ul>

<script>
 
$(document).ready(function(){
 
 //updating the view with notifications using ajax

function load_unseen_notification(view = '')
{
 $.ajax({
   url:"<?php echo base_url();?>user/dashboard/notif_pr_pm",
  method:"POST",
  data:{"view":view},
  dataType:"json",
  success:function(data)
  {
  // $('.show_data').html(data.notification);

   $('#count_pr_pm').show();
   if(data.unseen_notification > 0)
   {
       
    $('#count_pr_pm').html(data.unseen_notification);
   }  else if(data.unseen_notification == ''){

       $('#count_pr_pm').hide();

   }
  }
 });
}
setInterval(function(){
 
 load_unseen_notification();;
 
},2000);
 
});
 
</script>
<script>
 
$(document).ready(function(){
 
 //updating the view with notifications using ajax

function load_unseen_notification(view = '')
{
 $.ajax({
   url:"<?php echo base_url();?>user/dashboard/notif_pr_pm",
  method:"POST",
  data:{"view":view},
  dataType:"json",
  success:function(data)
  {
  // $('.show_data').html(data.notification);

   $('#count_pr_pm2').show();
   if(data.unseen_notification > 0)
   {
       
    $('#count_pr_pm2').html(data.unseen_notification);
   }  else if(data.unseen_notification == ''){

       $('#count_pr_pm2').hide();

   }
  }
 });
}
setInterval(function(){
 
 load_unseen_notification();;
 
},2000);
 
});
 
</script>
<script>
 
$(document).ready(function(){
 
 //updating the view with notifications using ajax

function load_unseen_notification(view = '')
{
 $.ajax({
   url:"<?php echo base_url();?>user/dashboard/notif_pr_pm3",
  method:"POST",
  data:{"view":view},
  dataType:"json",
  success:function(data)
  {
  // $('.show_data').html(data.notification);

   $('#count_pr_pm3').show();
   if(data.unseen_notification > 0)
   {
       
    $('#count_pr_pm3').html(data.unseen_notification);
   }  else if(data.unseen_notification == ''){

       $('#count_pr_pm3').hide();

   }
  }
 });
}
setInterval(function(){
 
 load_unseen_notification();;
 
},2000);
 
});
 
</script>
<script>
 
$(document).ready(function(){
 
 //updating the view with notifications using ajax

function load_unseen_notification(view = '')
{
 $.ajax({
   url:"<?php echo base_url();?>user/dashboard/notif_pr_estimator",
  method:"POST",
  data:{"view":view},
  dataType:"json",
  success:function(data)
  {
  // $('.show_data').html(data.notification);
   $('#count_pr_estimator').show();
   if(data.unseen_notification > 0)
   {
       
    $('#count_pr_estimator').html(data.unseen_notification);
   }  else if(data.unseen_notification == ''){

       $('#count_pr_estimator').hide();

   }
  }
 });
}
setInterval(function(){
 
 load_unseen_notification();;
 
},2000);
 
});
 
</script>

<script>
 
$(document).ready(function(){
 
 //updating the view with notifications using ajax

function load_unseen_notification(view = '')
{
 $.ajax({
   url:"<?php echo base_url();?>user/dashboard/notif_pr_purchase",
  method:"POST",
  data:{"view":view},
  dataType:"json",
  success:function(data)
  {
  // $('.show_data').html(data.notification);
   $('#count_pr_purchase').show();
   if(data.unseen_notification > 0)
   {
       
    $('#count_pr_purchase').html(data.unseen_notification);
   }  else if(data.unseen_notification == ''){

       $('#count_pr_purchase').hide();

   }
  }
 });
}
setInterval(function(){
 
 load_unseen_notification();;
 
},2000);
 
});
 
</script>