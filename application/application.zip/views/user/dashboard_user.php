<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('user/partials/head.php') ?>


    <script type="text/javascript">
// 1 detik = 1000
window.setTimeout("waktu()",1000);  
function waktu() {   
var tanggal = new Date();  
setTimeout("waktu()",1000);
document.getElementById("jam").innerHTML = tanggal.getHours()+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();  
document.getElementById("jam_datang").innerHTML = tanggal.getHours()+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();
document.getElementById("jam_pulang").innerHTML = tanggal.getHours()+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();
}
</script>
  <script language="JavaScript">
    var tanggallengkap = new String();
    var namahari = ("Minggu Senin Selasa Rabu Kamis Jumat Sabtu");
    namahari = namahari.split(" ");
    var namabulan = ("Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember");
    namabulan = namabulan.split(" ");
    var tgl = new Date();
    var hari = tgl.getDay();
    var tanggal = tgl.getDate();
    var bulan = tgl.getMonth();
    var tahun = tgl.getFullYear();
    tanggallengkap = namahari[hari] + ", " +tanggal + " " + namabulan[bulan] + " " + tahun;
    </script>

      <style type="text/css">
      .leave_apps{
    list-style: none;  
    margin-left: -42px;
    margin-top: -9px;
}
.ex3 {
  height: 338px;
  width: auto;

  overflow-y: auto;
}
    </style>
</head>

<body id="page-top"> 


	<div id="wrapper">
		<!-- load sidebar -->
		<?php $this->load->view('user/partials/sidebar.php') ?>

		<div id="content-wrapper" class="d-flex flex-column">
			<div id="content" data-url="<?= base_url('kasir') ?>">
				<!-- load Topbar -->
				<?php $this->load->view('user/partials/topbar.php') ?>

				<div class="container-fluid">
					<div class="clearfix">
						<div class="float-left">
							<h1 class="h3 m-0 text-gray-800"> <i></i>       
                Welcome To Alba <br>
        <!--Start Project  <a href="<?= base_url('user/absensi') ?>" class="btn btn-info btn-sm"><i class="fa fa-bars"></i>&nbsp;&nbsp;Silahkan Absen </a> End Project-->
						</div>
                        <div class="float-right " id='jam'>
                           
                        </div>
                        <div class="float-right" >
                            <h1 class="h3 m-0 text-gray-800"><script language='JavaScript'>document.write(tanggallengkap);</script>
                        </div>
					</div>
	<hr style="height:2px;border-width:0;color:red;background-color:#cacad3">
					<?php if ($this->session->flashdata('success')) : ?>
						<div class="alert alert-success alert-dismissible fade show" role="alert">
							<?= $this->session->flashdata('success') ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
					<?php elseif($this->session->flashdata('error')) : ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<?= $this->session->flashdata('error') ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
					<?php endif ?>
				                                   <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                      <!-- Start project  <div class="col-xl-12 col-md-6 mb-4">
                          <div class="card shadow mb-4">
                                
                                <div  
                                   class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Papan Pengumuman <i class="fa fa-bullhorn" style="color:red"></i></h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div> 
                               
           <div class="card-body ex3">
             <table class="table table"  width="100%" cellspacing="0">
                 <thead>
                                <tr>
                                    <th width="200">Dibuat</th>  
                                    <th>Uraian</th>
                                                                            
                                </tr>
                            </thead>
                  <tbody>   
                    <?php foreach ($pngumuman as $row): ?>                                
                                    <tr>
                                        <td><?= $row->created_p  ?><i><font size="1"> <?= $row->createdtime_p; ?></font></i></td>
                                        <td><?= $row->uraian  ?></td>   
                                                                            
                                    </tr>
                     <?php endforeach ?>                        
                        </tbody>
              </table>
                 

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="clearfix">
                        <div class="float-left">
                            <h1 class="h3 m-0 text-gray-800">Izin & Tugas Saya <i></i></h1>
                        </div>
                   
                    </div>
                       <hr style="height:2px;border-width:0;color:red;background-color:#cacad3">
                                        <div class="row">

                       -->
                 <!--    <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-warning text-uppercase mb-1"> <a target="_blank" href="wo/list_permintaan"> PERMINTAAN BARANG </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $total_permintaan ?></div>
                                </div> 
                                <div class="col-auto">
                                <a target="_blank" href="wo/list_permintaan">   <i class="fas   fa fa-navicon fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> -->
                        
                     <!--startPROSESPPIC   <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> <a target="_blank" href="wo/proses_permintaan_barang"> PROSES PPIC </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $permintaan_akan_diproses ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/proses_permintaan_barang">   <i class="fas   fa fa-pencil-square-o fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> end-->

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-success text-uppercase mb-1"> <a target="_blank" href="wo/master_wo"> WORK ORDER </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $hitung_wo ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/master_wo">   <i class="fas  fa fa-server fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-warning text-uppercase mb-1"> <a target="_blank" href="wo/Forecast"> FORECAST </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_forecast ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/Forecast">   <i class="fas  fa fa-cogs fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/cutting_line1"> CUTTING </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_cutting ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/cutting_line1">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>


                    <!--Start cutting2      <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/cutting_line2"> CUTTING Line 2 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_cutting_line2 ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/cutting_line2">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        
                         <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/cutting_line3"> CUTTING Line 3 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_cutting_line3 ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/cutting_line3">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> end cutting-->

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/punching_line1"> PUNCHING </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $hitung_punching ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/punching_line1">   <i class="fas  fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                  <!--startpunching2      <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/punching_line2"> PUNCHING Line 2 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $hitung_punching ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/punching_line2">   <i class="fas  fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/punching_line3"> PUNCHING Line 3 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $hitung_punching ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/punching_line3">   <i class="fas  fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> endPunching-->

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1">  <a target="_blank" href="wo/bending_line1"> BENDING</a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_bending ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/bending_line1">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      <!--startbending2  <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/bending_line2"> BENDING Line 2 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_bending ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/bending_line2">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/bending_line3"> BENDING Line 3 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_bending ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/bending_line3">   <i class="fas   fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> endBending2-->
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/welding_line1"> WELDING</a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_welding ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/welding_line1">   <i class="fas fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      <!--start welding  <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/welding_line2"> WELDING LINE 2 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_welding ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/welding_line2">   <i class="fas fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/welding_line3"> WELDING LINE 3 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_welding ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/welding_line3">   <i class="fas fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> endwelding-->
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/ps_line1"> PS </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_ps ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/ps_line1">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      <!--startPS  <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/ps_line2"> PS LINE 2 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_ps ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/ps_line2">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/ps_line3"> PS LINE 3 </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_ps ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/ps_line3">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> endPS-->
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/fa_line1"> FA</a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_fa ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/fa_line1">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      <!--start fa   <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/fa_line2"> FA LINE 2</a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_fa ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/fa_line2">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                         <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/fa_line3"> FA LINE 3</a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_fa ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/fa_line3">   <i class=" fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>end-->
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> <a target="_blank" href="wo/packing"> PACKING </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_packing ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/packing">   <i class="  fa fa-tasks fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                      <!--  <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> <a target="_blank" href="wo/wh_fg"> WH FG </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_wh ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/wh_fg">   <i class="fas fa fa-circle-o-notch fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> -->

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> <a target="_blank" href="wo/booking"> BOOKING </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_boking ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/booking">   <i class="fa fa-book fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> <a target="_blank" href="wo/pengiriman"> SIAP DIKIRIM </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_siap_dikirim ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/pengiriman">   
                                <i class="  fa fa-send-o fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                          <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                  <div class="text-xs font-weight-bold text-success text-uppercase mb-1"> <a target="_blank" href="wo/selesai"> Riwayat Pesanan </a></div>
                                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $hitung_pengiriman ?></div>
                                </div>
                                <div class="col-auto">
                                <a target="_blank" href="wo/selesai">   <i class="fas    fa fa-calendar-check-o fa-2x text-gray-000"></i></a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                  <div class="clearfix">
                        <div class="float-left">
                            <h1 class="h3 m-0 text-gray-800"><i></i></h1>
                        </div>
                   
                    </div>
                       <hr style="height:2px;border-width:0;color:red;background-color:#cacad3">
                                        <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                       <div class="col-lg-8 mb-4">
 <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Barang Dibawah Stok Minimum</h6>
    </div>
    <div class="card-body ex3">
      <table class="table table" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th >Kode</th>
            <th >Barang</th>  
            <th>Min</th>
            <th>Stok</th>                                            
          </tr>
        </thead>
        <tbody> 
          <?php foreach ($all_barang as $barang): ?>                     
            <tr>
              <td><?= $barang->Kode_Barang ?></td>
              <td><?= $barang->Nama_Barang ?></td>
              <td><?= $barang->Nama_Barang ?></td>
              <td><?= $barang->Min?></td>
              <td><?php 
                   if(empty($barang->Stok)){
                       echo 0;
                   }else{
                     //cek jumlah stok jika stok kurang dari min atau stok lebih dari max maka                tampilkan warna merah
                     if ($barang->Stok < $barang->Min OR $barang->Stok > $barang->Max){
                      echo '<span style="color: red;">' . $barang->Stok . ' ' .$barang->Satuan                . '</span>';
                     }else
                      // jika bukan
                     {
                       echo $barang->Stok . ' ' .$barang->Satuan;
                     }
                   }
                    ?></td>
              <td>
                <a href="<?= base_url('user/barang/ubah/' . $barang->No) ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                <a onclick="return confirm('apakah anda yakin?')" href="<?= base_url('user/barang/hapus_stok/' . $barang->No) ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
              </td>
            </tr>
          <?php endforeach ?>
        </tbody>
      </table>
    </div>
 </div>
</div>

				</div>
			</div>

			<!-- load footer -->
			<?php $this->load->view('user/partials/footer.php') ?>
		</div>
	</div>
	<?php $this->load->view('user/partials/js.php') ?>
	<script src="<?= base_url('sb-admin/js/demo/datatables-demo.js') ?>"></script>
	<script src="<?= base_url('sb-admin') ?>/vendor/datatables/jquery.dataTables.min.js"></script>
	<script src="<?= base_url('sb-admin') ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
     <script src="<?= base_url('sb-admin') ?>/js/demo/chart-area-demo.js"></script>
    <script src="<?= base_url('sb-admin') ?>/js/demo/chart-pie-demo.js"></script>
</body>
</html>