<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class quotation extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		if($this->session->login['role'] == ''){
			$this->session->set_flashdata('error01', 'Sessi Berakhir, Login Kembali!');
		redirect('login');
		}
		//$this->load->model('M_pengeluaran', 'm_pengeluaran');
		//$this->load->model('M_detail_keluar', 'm_detail_keluar');
		//$this->load->model('M_kerja', 'm_kerja');
		//$this->load->model('M_payment', 'm_payment');
		//$this->load->model('m_pembelian', 'm_pembelian');
		$this->load->model('M_mom', 'm_mom');
		$this->load->model('M_karyawan', 'm_karyawan');
		$this->load->model('M_sop', 'm_sop');
		$this->load->helper(array('form', 'url'));
		$this->load->model('M_barang', 'm_barang');
		$this->load->model('M_customer', 'm_customer');
		$this->load->model('M_sales', 'm_sales');
		//$this->load->model('M_kendaraan', 'm_kendaraan');
		$this->load->model('M_quotation', 'm_quotation');
	}

	public function get_all_barang(){  
      	$data = $this->m_barang->lihat_nama_barang1($_POST['Nama_Barang']); 
      	echo json_encode($data);
      }

    public function keranjang_barang_quo(){
      	$this->load->view('user/quotation/keranjang_quo');
      }

	public function tambah_quo($id_lsp = NULL){
		$this->data['aktif'] = 'quotation';
		$this->data['title'] = 'Quotation';
		$this->data['no'] = 1;

		$this->data['customer'] = $this->m_customer->lihat();
		$this->data['sales'] = $this->m_sales->lihat();
		$this->data['warna'] = $this->m_barang->lihat_warna(); //get data barang

		$this->data['all_barang'] = $this->m_barang->lihat_stok(); //get data barang
		$this->data['all_unit'] = $this->m_barang->lihat_satuan(); //get data Satuan Unit
		$this->data['satuan'] = $this->m_barang->lihat_satuan(); //get data Satuan Unit
		$id = $this->session->login['kode'];
		$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);

	$dariDB = $this->m_quotation->cekkode_quotation();

	$nourut = substr($dariDB, 6, 5);
	$kodenikSekarang = $nourut + 1; 
	$this->data['kode_nik']  = $kodenikSekarang ;

	$this->load->view('user/quotation/tambah_quo', $this->data);
}
    public function proses_tambah_quo(){

        date_default_timezone_set('Asia/Jakarta');
 
      	$jumlah_permintaan_barang_quo = count($this->input->post('detailName_quo_hidden'));
      	$trans_Date = $this->input->post('trans_Date'); 
      	$number_quo = $this->input->post('number_quo');
      	$kd_cst_quo = $this->input->post('kd_cst_quo'); 
      	$kdSales = $this->input->post('kdSales'); 
      	
      	$created_quo = $this->session->login['nama'];
      	$createdtime_quo = date('Y-m-d H:i:s');

      	$data_hd_quo['trans_Date'] = $trans_Date;		
      	$data_hd_quo['number_quo'] = $number_quo;
      	$data_hd_quo['kd_cst_quo'] = $kd_cst_quo;
      	$data_hd_quo['kdSales'] = $kdSales;
      	$data_hd_quo['created_quo'] = $created_quo;
      	$data_hd_quo['createdtime_quo'] = $createdtime_quo;
      	//$data_hd_quo['status_quo'] = '1';
			$this->m_quotation->save_quo_hd($data_hd_quo); //simpan ke tabel alba quotation hd

$data_detail_keluar_quo = [];

for ($i = 0; $i < $jumlah_permintaan_barang_quo; $i++) {
	
    if (!empty($_FILES['berkas']['name'][$i])) {
        $config['upload_path']          = './img/uploads/gambar_penawaran/'; // penempatan gambar 
        $config['allowed_types']        = 'gif|jpg|png|jpeg|pdf'; // upload tipe
        $config['max_size']             = 30000; // upload max size 30mb
        $config['encrypt_name']         = true;
        $this->load->library('upload', $config);  //konfigurasi file

        $_FILES['file']['name'] = $_FILES['berkas']['name'][$i];
        $_FILES['file']['type'] = $_FILES['berkas']['type'][$i];
        $_FILES['file']['tmp_name'] = $_FILES['berkas']['tmp_name'][$i];
        $_FILES['file']['error'] = $_FILES['berkas']['error'][$i];
        $_FILES['file']['size'] = $_FILES['berkas']['size'][$i];
        $this->upload->do_upload('file');
        $uploadData = $this->upload->data();
        $foto = $uploadData['file_name'];
        $data_detail_keluar_quo[$i]['gambar_penawaran'] = $uploadData['file_name'];
    } else {
        // Handle ketika tidak ada file diunggah
        $data_detail_keluar_quo[$i]['gambar_penawaran'] = ''; // Atau isikan dengan nilai default yang sesuai
    }

    $data_detail_keluar_quo[$i]['number_request_quo'] = $this->input->post('number_quo');
    $data_detail_keluar_quo[$i]['kd_cst_quo'] = $this->input->post('kd_cst_quo');
    $data_detail_keluar_quo[$i]['detailName_quo'] = $this->input->post('detailName_quo_hidden')[$i];
    $data_detail_keluar_quo[$i]['item_no'] = $this->input->post('item_no_hidden')[$i];
    $data_detail_keluar_quo[$i]['detailNotes_quo'] = $this->input->post('detailNotes_quo_hidden')[$i];
}
// yang status packing kiri itu nama field di tabel db nya, yang kanan itu yang dari program name yang dari keranjang

 // $this->db->insert('alba_permintaan_barang_dt',$data_detail_keluar_quo);
			$this->m_quotation->save_quo_dt1($data_detail_keluar_quo); //simpan ke tabel alba permintaan barang dt

			$data_hs_quo['no_qt'] = $number_quo;
			$data_hs_quo['status'] = 'Quotation berhasil dibuat';
			$data_hs_quo['action_qt_by'] = $created_quo;
			$data_hs_quo['actiontime_qt'] = $createdtime_quo;
			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel alba purchase history

			$this->session->set_flashdata('success', 'Permintaan <strong>Barang</strong> Berhasil Dibuat!');
			redirect('user/quotation/list_quo_order'); //redirect page

			//echo '<pre>';
//print_r($this->input->post());
//die();
		}

		public function list_quotation_item($id_lsp = NULL){
      	$this->data['aktif'] = 'quotation';
      	$this->data['title'] = 'Quotation Order Progress';
		//$this->data['all_Mom'] = $this->m_mom->lihat();
      	$this->data['no'] = 1;
      	$id = $this->session->login['kode'];
      	$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);
		//$this->data['count_task'] = count($this->m_kerja->my_modul()); // get resutl 
		//$this->data['view_task'] = $this->m_kerja->my_modul();
		//$this->data['all_leads_project'] = $this->m_mom->get_lsp();
		//$this->data['proyek'] = $this->m_mom->get_project();
		//$this->data['vendor'] = $this->m_payment->lihat();
        
        $this->data['all_quo'] = $this->m_quotation->lihat_Item_quo_status_belum_proses_01();
		$this->load->view('user/quotation/list_all_item_quo', $this->data);
		//echo '<pre>';
//print_r($this->input->post());
//die();
	}

		public function list_quo_order($id_lsp = NULL){
      	$this->data['aktif'] = 'quotation';
      	$this->data['title'] = 'Quotation Order List';
      	$this->data['no'] = 1;
      	$id = $this->session->login['kode'];
      	$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);

			$this->data['all_quo'] = $this->m_quotation->lihat_quo_status_1(); 

		$this->load->view('user/quotation/list_quo', $this->data);
	}

	public function detail_quo($id_quo = NULL){
		$this->data['aktif'] = 'quotation';
		$this->data['title'] = 'Quotation Order Details';
		//$this->data['all_Mom'] = $this->m_mom->lihat();
		$this->data['no'] = 1;
		$id = $this->session->login['kode'];
		$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);


		$this->data['hd_quo'] = $this->m_quotation->lihat_quo_detail_hd($id_quo);
		$this->data['dt_quo'] = $this->m_quotation->lihat_quo_detail_dt($id_quo);
		$this->data['his_quo'] = $this->m_quotation->lihat_quo_detail_history($id_quo); 
		$this->data['customer'] = $this->m_customer->lihat();
		$this->data['sls'] = $this->m_sales->lihat();

		$this->load->view('user/quotation/detail_quo', $this->data); 
	}

	public function proses_approve_quo(){
			date_default_timezone_set('Asia/Jakarta'); 
			
			$id_hd = $this->input->post('id');
			$data['status_quo'] = $this->input->post('status_quo');
      		$this->m_quotation->ubah_status_quo($data,$id_hd); //simpan ke tabel jenis izin


      		$data_log['user'] = $this->session->login['nama'];
      		$data_log['waktu'] = date('Y-m-d H:i:s');
      		$data_log['ket'] = 'Estimator Mengetahui Quotation';
      		$data_log['kode'] = $this->input->post('number_quo');
			$this->m_mom->tambah_log($data_log); //simpan ke tabel log data

			$data_hs['action_qt_by'] = $this->session->login['nama'];
			$data_hs['actiontime_qt'] = date('Y-m-d H:i:s');
			$data_hs['no_qt'] = $this->input->post('number_quo');
			$data_hs['status'] = $this->input->post('status');
			$this->m_quotation->save_quotation_history($data_hs); //simpan ke tabel History Po

			$this->session->set_flashdata('error', 'Detail PR <strong>Gagal</strong> Ditambahkan!');
			$this->session->set_flashdata('success', 'Permintaan Barang <strong>Berhasil</strong> Disetujui!');
			redirect('user/quotation/detail_quo/'.$id_hd);

      //  echo '<pre>';
     //   print_r ($_POST);
      //  echo '</pre>';
     //   exit;
		}	



	public function kelengkapan_quo($id_quo = NULL){
      	$this->data['aktif'] = 'quotation';
      	$this->data['title'] = 'Estimasi';

      	$this->data['no'] = 1;
				$id = $this->session->login['kode'];
				$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);
				$this->data['all_barang'] = $this->m_barang->lihat_stok(); //get data barang
				//$this->data['satuan'] = $this->m_barang->lihat_satuan(); //get data Satuan Unit
				//$this->data['warna'] = $this->m_barang->lihat_warna(); //get data warna
				
				$this->data['dt_quo'] = $this->m_quotation->lihat_quo_detail_dt_aksi($id_quo);
				$this->data['dt_quo_all'] = $this->m_quotation->lihat_quo_detail_dt_aksi_all($id_quo);

				$this->data['hd_quo'] = $this->m_quotation->lihat_quo_detail_hd($id_quo);

				$dariDB_wo = $this->m_quotation->cekkode_pesanan_quo(); //ambil kode WO dari tabel alba_kode_otomatis
				$nourut_wo = substr($dariDB_wo, 11, 4); // ambil 4 angka kode urutan ke 11 
				$kodeWO = $nourut_wo + 1; // kode terakhir di tambah 1
		    	$this->data['generate_kode_wo']  = $kodeWO; // hasill

				//$dariDB_stok = $this->m_quotation->cekkode_stok(); //ambil kode Stok dari tabel alba_kode_otomatis
				//$nourut_stok = substr($dariDB_stok, 10, 4); // ambil 4 angka kode urutan ke 11 
				//$kodeStok = $nourut_stok + 1; // kode terakhir di tambah 1
		    	//$this->data['generate_kode_stok']  = $kodeStok; // hasill


      	$this->load->view('user/quotation/ubah_quo', $this->data);
      }

    
    public function ubah_quo_dt_prosesto_est(){
			date_default_timezone_set('Asia/Jakarta');

			$id_hd = $this->input->post('id_header');
			$cek_status =  $this->input->post('status_qr_quo');
			$customer =  $this->input->post('customer');			
			$cek_status_proses =  $this->input->post('status_proses_quo');
			
			
			//validasi jika status produksi  maka beri pesan berhasil simpan .
			if($cek_status == 'Dalam Proses Estimasi' || $cek_status == 'Partlist Required'  ){

				if (!empty($_FILES['estimasi_harga']['name'])) {
				$config['upload_path']          = './img/uploads/estimasi_harga';
				$config['allowed_types']        = '*';
				$config['max_size']             = 20000;
				$config['encrypt_name']			= TRUE;
				$this->load->library('upload', $config);
				$this->upload->do_upload('estimasi_harga');

				$update_quo_dt['estimasi_harga'] = $this->upload->data("file_name");
			}
			
			$update_quo_dt['id_quo_dt'] = $this->input->post('id_quo_dt');
			$update_quo_dt['detailName_quo'] = $this->input->post('detailName_quo');	
			$update_quo_dt['detailNotes_quo'] = $this->input->post('detailNotes_quo');
			$update_quo_dt['status_proses_quo'] = $this->input->post('status_proses_quo');
			$update_quo_dt['status_qr_quo'] = $this->input->post('status_qr_quo');
			
			//$update_quo_dt['status_awal'] = $this->input->post('status_qr');

			  $data_log['user'] = $this->session->login['nama'];
		      $data_log['waktu'] = date('Y-m-d H:i:s');
		      $data_log['ket'] = 'Update Detail Barang';
		      $data_log['kode'] = $this->input->post('id_quo_dt');
					

			$data_hs['action_qt_by'] = $this->session->login['nama'];
			$data_hs['actiontime_qt'] = date('Y-m-d H:i:s');
			$idnya = $this->input->post('id_quo_dt');
			$data_hs['no_qt'] = $this->input->post('no_qt');
			$data_hs['status'] = 'Update Detail Barang id '.$idnya;
				$this->m_quotation->save_update_quo_dt($update_quo_dt); //simpan ke tabel pr dt	
			$this->m_mom->tambah_log($data_log); //simpan ke tabel log 	
			$this->session->set_flashdata('success', 'Detail PR <strong>Berhasil</strong> Diubah!');
			redirect('user/quotation/kelengkapan_quo/'.$id_hd);
			}
			

        //echo '<pre>';
        //print_r ($_POST);
        //echo '</pre>';
        //exit;
		
		}

	public function delete_detail_quo()
	    {
	    	if($this->input->post('checkbox_value'))
	    	{


	    		$id = $this->input->post('checkbox_value');
	    		for($count = 0; $count < count($id); $count++)
	    		{
	    			$this->m_quotation->hapus_quo_dt1($id[$count]);
	    		}
	    	}
	    }

	

    public function proses_permintaan_barang($id_lsp = NULL){
      	$this->data['aktif'] = 'quotation';
      	$this->data['title'] = 'Permintaan Quotation Sedang Diproses';
      	$this->data['no'] = 1;
      	$id = $this->session->login['kode'];
      	$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);

			$this->data['all_quo'] = $this->m_quotation->lihat_quo_status_2(); 


		$this->load->view('user/quotation/list_quo', $this->data);
	}

	public function master_qt($id_lsp = NULL){
		$this->data['aktif'] = 'quotation';
		$this->data['title'] = 'Master Quotation'; 
		$this->data['no'] = 1;
		$id = $this->session->login['kode'];
      	$this->data['emp'] = $this->m_karyawan->view_profile_employee($id);
		
		$this->data['all_quo'] = $this->m_quotation->list_master_qt();
		
		 
		$this->load->view('user/quotation/master_qt', $this->data);
		    //  echo '<pre>';
        // print_r ($_POST);
        // echo '</pre>';
        // exit;
	}

    public function ubah_master_qt(){
			date_default_timezone_set('Asia/Jakarta');
			        //echo '<pre>';
       //print_r ($_POST);
       // echo '</pre>';
       //exit;

           
			if ( $this->input->post('status_pembatalan') == 'Batal' ){
	
	        $status_qr_quo = 'Batal';
            }
            if ( $this->input->post('status_pembatalan') != 'Batal' ){
	
	        $status_qr_quo = $this->input->post('status_qr_quo');
            }

			$id_hd = $this->input->post('url');


// Proses unggah file estimasi_harga
if (!empty($_FILES['estimasi_harga']['name'])) {
    $config_estimasi_harga = [
        'upload_path'   => './img/uploads/estimasi_harga',
        'allowed_types' => '*', // Sesuaikan tipe file jika diperlukan
        'max_size'      => 20000, // Maksimal ukuran 20 MB
        'encrypt_name'  => TRUE, // Nama file akan diacak
    ];

    $this->load->library('upload', $config_estimasi_harga, 'upload_estimasi_harga'); // Buat instance upload khusus untuk estimasi_harga

    if ($this->upload_estimasi_harga->do_upload('estimasi_harga')) {
        $update_dt['estimasi_harga'] = $this->upload_estimasi_harga->data("file_name");
    } else {
        $error = $this->upload_estimasi_harga->display_errors();
        echo "Error Upload Estimasi: " . $error;
    }
}
           			
			$update_quo_dt['status_qr_quo'] = $status_qr_quo;
			$update_quo_dt['id_quo_dt'] = $this->input->post('id_quo_dt');
            $update_quo_dt['detailNotes_quo'] = $this->input->post('detailNotes_quo');


		$data_log['user'] = $this->session->login['nama'];
      	$data_log['waktu'] = date('Y-m-d H:i:s');
      	$data_log['ket'] = 'Update Detail Barang';
      	$data_log['kode'] = $this->input->post('id_quo_dt');
			

			$data_hs_quo['action_qt_by'] = $this->session->login['nama'];
			$data_hs_quo['actiontime_qt'] = date('Y-m-d H:i:s');
			$idnya = $this->input->post('id_quo_dt');
			$data_hs_quo['no_qt'] = $this->input->post('no_qt');
			$data_hs_quo['status'] = 'Update Detail Barang id '.$idnya;

			

			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel log status pr

			$this->m_quotation->save_update_quo_dt($update_quo_dt); //simpan ke tabel pr dt	

			$this->m_mom->tambah_log($data_log); //simpan ke tabel log 	
			$this->session->set_flashdata('success', 'Data Barang <strong>Berhasil</strong> Diubah!');
			redirect('user/quotation/'.$id_hd);
		  
       //echo '<pre>';
       //print_r ($_POST);
       //echo '</pre>';
       //exit;
		}

    public function ubah_quo_dt(){ 
		date_default_timezone_set('Asia/Jakarta');

		$id_hd = $this->input->post('id_header');

		if (!empty($_FILES['estimasi_harga']['name'])) {
				$config['upload_path']          = './img/uploads/estimasi_harga';
				$config['allowed_types']        = '*';
				$config['max_size']             = 20000;
				$config['encrypt_name']			= TRUE;
				$this->load->library('upload', $config);
				$this->upload->do_upload('estimasi_harga');

				$update_quo_dt['estimasi_harga'] = $this->upload->data("file_name");
			}
		

		$update_quo_dt['id_quo_dt'] = $this->input->post('id_quo_dt');
		$update_quo_dt['detailName_quo'] = $this->input->post('detailName_quo');	
		$update_quo_dt['detailNotes_quo'] = $this->input->post('detailNotes_quo');
    $this->m_quotation->save_update_quo_dt($update_quo_dt); //simpan ke tabel alba_permintaan_barang_dt


			$data_hs_quo['action_qt_by'] = $this->session->login['nama'];
			$data_hs_quo['actiontime_qt'] = date('Y-m-d H:i:s');
			$idnya = $this->input->post('id_quo_dt');
			$data_hs_quo['no_qt'] = $this->input->post('no_qt');
			$data_hs_quo['status'] = 'Update Estimasi Harga id '.$idnya;
			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel log status pr

			$this->session->set_flashdata('error', 'Detail QT <strong>Gagal</strong> Ditambahkan!');
			$this->session->set_flashdata('success', 'Detail QT <strong>Berhasil</strong> Diubah!');
			redirect('user/quotation/detail_quo/'.$id_hd);

      //  echo '<pre>';
     //   print_r ($_POST);
      //  echo '</pre>';
     //   exit;
		}
    
    public function update_quo_pl(){ 
		date_default_timezone_set('Asia/Jakarta');

		$id_hd = $this->input->post('id_header');

		if (!empty($_FILES['partList']['name'])) {
				$config['upload_path']          = './img/uploads/part_list';
				$config['allowed_types']        = '*';
				$config['max_size']             = 20000;
				$config['encrypt_name']			= TRUE;
				$this->load->library('upload', $config);
				$this->upload->do_upload('partList');

				$update_quo_dt['partList'] = $this->upload->data("file_name");
			}
		
		$update_quo_dt['id_quo_dt'] = $this->input->post('id_quo_dt');
		//$update_quo_dt['detailName_quo'] = $this->input->post('detailName_quo');	
		//$update_quo_dt['detailNotes_quo'] = $this->input->post('detailNotes_quo');
    $this->m_quotation->save_update_quo_dt($update_quo_dt); //simpan ke tabel alba_permintaan_barang_dt

			$data_hs_quo['action_qt_by'] = $this->session->login['nama'];
			$data_hs_quo['actiontime_qt'] = date('Y-m-d H:i:s');
			$idnya = $this->input->post('id_quo_dt');
			$data_hs_quo['no_qt'] = $this->input->post('no_qt');
			$data_hs_quo['status'] = 'Update Part List id '.$idnya;
			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel log status pr

			$this->session->set_flashdata('error', 'Detail QT <strong>Gagal</strong> Ditambahkan!');
			$this->session->set_flashdata('success', 'Detail QT <strong>Berhasil</strong> Diubah!');
			redirect('user/quotation/detail_quo/'.$id_hd);

      //  echo '<pre>';
     //   print_r ($_POST);
      //  echo '</pre>';
     //   exit;
		}
    
    public function update_status() {
    	date_default_timezone_set('Asia/Jakarta');
    	
    $id_hd = $this->input->post('id_header');
    $id_quo_dt = $this->input->post('id_quo_dt');
    $status_qr_quo = $this->input->post('status_qr_quo');

    // Ambil status lama dari database
    $data_lama = $this->m_quotation->get_quo_dt_by_id($id_quo_dt); // Buat method ini di model
    if (strtolower($data_lama['status_qr_quo']) === 'selesai') {
        $this->session->set_flashdata('error', 'Status tidak dapat diubah karena sudah "Selesai".');
        redirect('user/quotation/detail_quo/'.$id_hd);
        return;
    }

    // Lanjut update jika belum selesai
    $update_quo_dt['id_quo_dt'] = $id_quo_dt;
    $update_quo_dt['status_qr_quo'] = $status_qr_quo;
    $this->m_quotation->save_update_quo_dt($update_quo_dt);

    // Update status proses jika Selesai
    if (strtolower($status_qr_quo) === 'selesai') {
        $update_status_proses = ['status_proses_quo' => 4];
        $this->m_quotation->update_status_proses($id_hd, $id_quo_dt, $update_status_proses);
    }

    // History
    $data_hs_quo['action_qt_by'] = $this->session->login['nama'];
			$data_hs_quo['actiontime_qt'] = date('Y-m-d H:i:s');
			$idnya = $this->input->post('id_quo_dt');
			$data_hs_quo['no_qt'] = $this->input->post('no_qt');
			$data_hs_quo['status'] = 'Update Status id '.$idnya;
			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel log status pr

    $this->session->set_flashdata('success', 'Detail QT <strong>Berhasil</strong> Diubah!');
    redirect('user/quotation/detail_quo/'.$id_hd);
}

    public function quo_item_selesai($id_lsp = NULL){
    $this->data['aktif'] = 'quotation';
    $this->data['title'] = 'Selesai';
    $this->data['no'] = 1;
    $id = $this->session->login['kode'];
    $this->data['emp'] = $this->m_karyawan->view_profile_employee($id);
    //$jenis_status = 'Selesai';
    
    $this->data['all_quo'] = $this->m_quotation->lihat_quo_selesai();

     //$this->m_quotation->lihat_quo_selesai(); //simpan ke tabel log status pr
 
    $this->load->view('user/quotation/list_quo_selesai_item', $this->data);
}   
    
    public function hapus_quo($id){
		date_default_timezone_set('Asia/Jakarta');
		$data_log['user'] = $this->session->login['nama'];
		$data_log['waktu'] = date('Y-m-d H:i:s');
		$data_log['ket'] = 'Hapus Permintaan Barang';
		$data_log['kode'] = $id;


		if(!empty($id)){ 
			$this->m_quotation->hapus_quo_dt($id);
			$this->m_quotation->hapus_quo_history($id);
			$this->m_quotation->hapus_quo_hd($id) ;
			$this->session->set_flashdata('success', 'Permintaan Barang <strong>Berhasil</strong> Dihapus!');
			redirect('user/quotation/list_quo_order'); //redirect page
		} else {
			$this->session->set_flashdata('error', 'Supplier <strong>Gagal</strong> Dihapus!');
			redirect('user/quotation/list_quo_order'); //redirect page
		}
	}
    
 
public function save_quo_sattle($id = NULL) { 
			date_default_timezone_set('Asia/Jakarta');
  //  echo '<pre>';
  //      print_r ($_POST);
   //     echo '</pre>';
    //   exit;
			$id_hd = $this->input->post('id');

			// Data untuk update ke header
    $data_qt['number_1'] = $this->input->post('number_1');
    $data_qt['created_quo'] = $this->session->login['nama'];
    $data_qt['createdtime_quo'] = date('Y-m-d H:i:s');

    // Update number_1 ke tabel header, bukan insert
    $this->m_quotation->update_number_quo($id_hd, $data_qt);

			
			$data_qt['created_quo'] = $this->session->login['nama'];
			$data_qt['createdtime_quo'] = date('Y-m-d H:i:s');
			$this->m_quotation->simpan_qt_dt($data_qt); //Update pr hd

			$data_kode_quo['kode_otomatis'] = $this->input->post('number_1');
			$this->m_quotation->simpan_kode_terakhir_quo($data_kode_quo); //simpan_kode_terakhir

		
		$number_po = $this->input->post('number_1');
		
		$number_1 = $this->input->post('number_quo');
		$detailName_quo = $this->input->post('detailName_quo');   
		$kd_cst_quo = $this->input->post('kd_cst_quo');  
		//$estimasi_harga = $this->input->post('estimasi_harga'); 
		$status_proses_quo = $this->input->post('status_proses_quo');  

		$detailNotes_quo = $this->input->post('detailNotes_quo');
   
		$id_quo_dt = $this->input->post('id_quo_dt');

    		$this->m_quotation->save_quo_sattle_dt($number_po,$number_1,$detailName_quo,$id_quo_dt,$status_proses_quo,$detailNotes_quo,$kd_cst_quo); //untuk tabel quo dt

    	//	$this->m_quotation->save_po_dt($number_po,$number_,$detailName,$itemNo,$quantity,$id_dt,$itemUnitName,$warna,$estimasi_harga,$status_proses_pr,$detailNotes, $qr_code ); //untuk tabel purchase d


    			$data_hs_quo['no_qt'] = $number_1;
    			$data_hs_quo['status'] = 'Quotation Baru '.$number_po;
    			$data_hs_quo['action_qt_by'] = $this->session->login['nama'];
    			$data_hs_quo['actiontime_qt'] = date('Y-m-d H:i:s');
			$this->m_quotation->save_quo_history($data_hs_quo); //simpan ke tabel quo history


        //   echo '<pre>';
        //  // print_r ($_POST);
        // echo '</pre>';
       //print POST
        //print_r($this->db->last_query()); //print query
        //exit;

//echo '<pre>';
//print_r($id_quo_dt);
//echo '</pre>';
//exit;
			$this->session->set_flashdata('error', 'PR <strong>Gagal</strong> Ditambahkan!');
			$this->session->set_flashdata('success', 'Data <strong>Berhasil</strong> Ditambahkan!');
       redirect('user/quotation/proses_permintaan_barang'); //redirect page
     }
	}
